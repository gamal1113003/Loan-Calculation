Loan Calculation using Java
